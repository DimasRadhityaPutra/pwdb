function validateForm() {
    var name = document.myForm.name.value;
    var email = document.myForm.email.value;

    var regex = /^[a-z0-9][a-z0-9_\.-]{0,}[a-z0-9]@[a-z0-9][a-z0-9_\.-]{0,}[a-z0-9][\.][a-z0-9]{2,4}$/;

    if (name == "") {
        alert("Nama tidak boleh kosong");
        return false;
    }
    if (email == "") {
        alert("Email tidak boleh kosong");
        return false;
    }
    if (!regex.test(email)) {
        alert("Format email tidak valid");
        return false;
    }
    return true;
}