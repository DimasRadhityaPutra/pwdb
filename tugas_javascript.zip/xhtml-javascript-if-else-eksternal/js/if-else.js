function checkData() {
    var age = prompt("Masukkan umur: ");
    var gender = prompt("Masukkan jenis kelamin (M/F): ");

    if (age >= 17 && gender == "M") {
        alert("Anda adalah pria dewasa");
    } else if (age >= 17 && gender == "F") {
        alert("Anda adalah wanita dewasa");
    } else if (age < 17 && gender == "M") {
        alert("Anda adalah pria remaja");
    } else if (age < 17 && gender == "F") {
        alert("Anda adalah wanita remaja");
    } else {
        alert("Input tidak valid");
    }
}